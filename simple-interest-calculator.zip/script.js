function calculateInterest() {
  const principal = parseFloat(document.getElementById("principal").value);
  const rate = parseFloat(document.getElementById("rate").value);
  const time = parseFloat(document.getElementById("time").value);
  const result = document.getElementById("result");

  if (isNaN(principal) || isNaN(rate) || isNaN(time) ||
      principal < 0 || rate < 0 || time < 0) {
    result.innerHTML = "Please enter valid positive values.";
    return;
  }

  // Simple Interest = (P × R × T) / 100
  const interest = (principal * rate * time) / 100;
  const total = principal + interest;

  result.innerHTML =
    "<strong>Simple Interest:</strong> " + interest.toFixed(2) +
    "<br><strong>Total Amount:</strong> " + total.toFixed(2);
}
