# Simple Interest Calculator

A simple web-based calculator that calculates simple interest and the total amount.

## Formula

**Simple Interest = (P × R × T) / 100**

Where:

- P = Principal amount
- R = Annual interest rate
- T = Time in years

**Total Amount = Principal + Simple Interest**

## Technologies Used

- HTML5
- CSS3
- JavaScript

## How to Run

1. Download or clone this repository.
2. Open `index.html` in any web browser.
3. Enter the principal amount, annual interest rate, and time in years.
4. Click **Calculate**.

## Example

If:

- Principal = 10,000
- Rate = 5%
- Time = 2 years

Then:

- Simple Interest = 1,000
- Total Amount = 11,000

## Author

Harshitha L
